Put your EZs here and use rabbitmq-plugins.bat to enable them.
